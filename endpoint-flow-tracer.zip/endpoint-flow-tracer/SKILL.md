---
name: endpoint-flow-tracer
description: Trace a provided target, downstream, internal, SAPI, or underlying API endpoint back to customer-facing/source PAPI endpoints in large legacy multi-module codebases. Use when asked to create migration-ready endpoint analysis, find all PAPI endpoints that call a provided SAPI endpoint, produce end-to-end PAPI-to-SAPI flow, strict PAPI/SAPI request and response mapping tables, conversion or derivation logic, JSON examples, validation and error handling behavior, confidence levels for uncertain mappings, evidence references, and an HTML report with sequence diagram source such as PlantUML.
---

# Endpoint Flow Tracer

## Overview

Use this skill to trace an endpoint through a large codebase and produce a migration-ready HTML report explaining the existing PAPI behavior that must be preserved while a new API connects to the same SAPI. Treat SAPI request/response shape as stable, treat existing PAPI mapping/error behavior as critical migration requirements, favor evidence from code over naming guesses, and mark every uncertain conclusion with confidence and confirmation notes.

## Workflow

1. Normalize the endpoint the user provides.
   - Capture method, path, host/base path, query parameters, example payloads, headers, module names, or known downstream system names if provided.
   - If method or module is missing, search broadly first; ask a targeted question only when the trace cannot proceed without it.

2. Discover matching code locations.
   - Use `rg` first. Search literal path fragments, path constants, operation names, DTO names, Feign/RestTemplate/WebClient client methods, OpenAPI specs, route annotations, and config keys.
   - Search both exact and normalized variants: with/without leading slash, path variables replaced by regex-like fragments, snake/camel/kebab forms, and URL-encoded forms.
   - For Java/Spring-heavy projects, read `references/tracing-checklist.md` when useful.

3. Identify endpoint direction and API roles.
   - Label the existing customer-facing/source endpoint as `PAPI`.
   - Label the provided target/downstream/underlying endpoint as `SAPI` unless the code proves a different naming convention.
   - If the match is a controller/router, treat it as a possible PAPI endpoint.
   - If the match is a client/proxy/gateway call, trace callers upward until reaching PAPI controllers, message consumers, schedulers, or public gateway routes.
   - If multiple PAPI endpoints call the same SAPI, report each flow separately and highlight this in the final `References and Evidence` section as a migration risk/confirmation item. Include each PAPI route, method/class, and evidence proving it calls the SAPI.

4. Build the call chain.
   - Follow controller/route -> service/facade/orchestrator -> mapper/converter/assembler -> downstream client -> target endpoint.
   - Include interceptors, filters, validators, exception handlers, retry/circuit-breaker layers, async queues, feature flags, and config-driven route rewrites when they materially change behavior.
   - Record file paths and line numbers for each important claim.

5. Extract request mappings.
   - Compare PAPI request DTOs, headers, query/path variables, auth/session/context fields, defaults, constants, config values, and computed fields against SAPI request DTOs.
   - Classify each mapping as one of: direct, renamed, transformed, derived, defaulted, conditional, omitted, aggregated, split, unknown.
   - Capture conversion expressions, helper methods, enum/value translations, date/time/number formatting, null handling, validation, and fallback behavior.
   - Fill the request mapping table with exactly these six columns: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - Use attribute type values such as `header`, `request payload`, `path parameter`, `query parameter`, `context/session`, `constant/default`, or `not sent`.
   - Make `Comments` specific enough for implementation: direct copy, source method/expression, conversion rules, null/default behavior, conditions, constants, enum translations, formatting, trimming, omission reason, and evidence reference IDs when available.

6. Extract response mappings.
   - Compare SAPI response DTOs to PAPI response DTOs.
   - Capture direct copies, wrapping/unwrapping, filtering, sorting, enrichment from other calls, derived fields, status/result code translation, default values, and omitted downstream fields.
   - Fill the response mapping table with exactly these six columns: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - Use attribute type values such as `header`, `response payload`, `status code`, `derived`, `constant/default`, `not returned`, or `not provided by SAPI`.
   - In `Comments`, explain how SAPI data becomes PAPI output, including direct copy, rename, wrapping, derived values, code/message translation, field omission, enrichment, sorting/filtering, null/default behavior, and evidence reference IDs.

7. Capture request and response examples.
   - Include four JSON examples when evidence allows: PAPI request, SAPI request, SAPI response, PAPI response.
   - Preserve headers separately from payloads when possible.
   - If examples cannot be fully proven, provide representative JSON with uncertain fields marked by comments outside the JSON block, not invalid JSON.

8. Trace error handling.
   - Find local `try/catch`, exception mappers/advice, client error decoders, retry policies, timeout handling, circuit breakers, validation failures, and downstream error-to-consumer error translations.
   - Include required/null/blank field behavior, validation annotations, manual validation, default-and-continue behavior, skip/omit behavior, downstream status/code/body translation, logging/audit behavior, and whether errors are swallowed, converted, retried, or propagated.
   - Be explicit for each important field: if `null`, blank, malformed, out-of-range, or unknown enum occurs, state whether processing errors, defaults, continues, omits the field, calls SAPI anyway, or returns a mapped error.

9. Assign confidence.
   - `High`: confirmed by explicit code path and DTO/mapper evidence.
   - `Medium`: code strongly implies the mapping, but dynamic config/reflection/generation prevents full proof.
   - `Low`: naming or partial evidence only.
   - `Requires confirmation`: runtime routing, undocumented gateway behavior, missing generated sources, environment config, or ambiguous overloads make the conclusion unverifiable from local code.

10. Generate the report.
   - Create the HTML directly when it is faster: use direct HTML for one-off reports, smaller traces, or when the report is unlikely to be regenerated from structured data.
   - Use the structured JSON findings file plus `scripts/render_endpoint_report.py` when the report is large, needs repeatable regeneration, needs programmatic edits, includes many PAPI flows, or the user wants the findings source preserved separately.
   - If using direct HTML, still follow the exact section order and table columns below. Inline the CSS from `assets/report-style.css` or use equivalent simple styling.
   - Embed PlantUML source in the report. If network/rendering is unavailable, include the diagram source in a readable code block; do not block the report on image rendering.
   - Save the report near the workspace root or in a user-requested output directory, with a name like `endpoint-flow-report-<safe-endpoint>.html`.

## Report Requirements

The HTML report must be development-ready for migration work. Use the following section order and do not move evidence above the functional sections:

1. End-to-End Flow
   - Include PAPI endpoint(s), SAPI endpoint(s), modules/classes/methods, route/controller/client chain, validators, mappers, service orchestration, downstream calls, response mapping, and return path.
   - Make this section as detailed as the code supports. Include PlantUML sequence diagram source in this section.

2. Data Mapping
   - Include `Request table` with exactly six columns: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - Include `Response table` with exactly six columns: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - Put all conversion, derivation, defaulting, omission, validation side effects, and field-level uncertainty in `Comments`.

3. Request and Response Examples
   - Include valid JSON examples for PAPI request, SAPI request, SAPI response, and PAPI response.
   - Keep headers and payloads visible. Use empty objects only when the code proves there are no fields.

4. Error Handling Logic
   - Include validation, null/blank/malformed behavior, downstream error handling, retries/fallbacks/timeouts, exception mapping, and final PAPI error response shape.
   - Be detailed enough for developers to implement compatible migration behavior.

5. References and Evidence
   - If the same SAPI endpoint is called by multiple PAPI endpoints, put a clear highlighted note at the top of this section. State that the SAPI has multiple PAPI callers and list every discovered PAPI caller with evidence.
   - List evidence for derivation logic, request/response mapping comments, error handling, route discovery, and confidence decisions.
   - Include file path, line number when available, class/method/field names, and a short explanation of what the evidence proves.
   - Include open questions or confirmation needs at the end of this section.

## Practical Search Patterns

Use fast, narrow searches first, then broaden:

```bash
rg -n "literal/path|operationName|DownstreamClient|RequestDto|ResponseDto" .
rg -n "@(Get|Post|Put|Delete|Patch)Mapping|@RequestMapping|RouterFunction|route\\(" .
rg -n "FeignClient|RestTemplate|WebClient|HttpClient|exchange\\(|retrieve\\(|postFor|send\\(" .
rg -n "Mapper|Converter|Assembler|Translator|Adapter|from\\(|to\\(|map\\(" .
rg -n "ControllerAdvice|ExceptionHandler|ErrorDecoder|Retry|CircuitBreaker|fallback|timeout" .
```

When `rg` finds too much, restrict by module, DTO name, package, or endpoint fragment. Prefer reading nearby files and referenced DTOs over trying to infer from search results alone.

## Bundled Resources

- `references/tracing-checklist.md`: framework and artifact checklist for common legacy endpoint tracing patterns.
- `scripts/render_endpoint_report.py`: renders a structured JSON trace into a standalone HTML report.
- `assets/report-style.css`: stylesheet embedded by the renderer.
