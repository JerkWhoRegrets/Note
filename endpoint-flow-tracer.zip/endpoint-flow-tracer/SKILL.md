---
name: endpoint-flow-tracer
description: Trace a provided target, downstream, internal, or underlying API endpoint back to customer-facing/source endpoints in large legacy multi-module codebases. Use when asked to find end-to-end endpoint flow, controller-to-service-to-client call chains, request/response field mappings, conversion or derivation logic, validation and error handling, confidence levels for uncertain mappings, and to generate an HTML report with sequence diagram source such as PlantUML.
---

# Endpoint Flow Tracer

## Overview

Use this skill to trace an endpoint through a large codebase and produce a self-contained HTML report explaining source/customer-facing endpoint candidates, downstream calls, request and response mappings, conversion logic, and error behavior. Favor evidence from code over naming guesses, and mark every uncertain conclusion with confidence and confirmation notes.

## Workflow

1. Normalize the endpoint the user provides.
   - Capture method, path, host/base path, query parameters, example payloads, headers, module names, or known downstream system names if provided.
   - If method or module is missing, search broadly first; ask a targeted question only when the trace cannot proceed without it.

2. Discover matching code locations.
   - Use `rg` first. Search literal path fragments, path constants, operation names, DTO names, Feign/RestTemplate/WebClient client methods, OpenAPI specs, route annotations, and config keys.
   - Search both exact and normalized variants: with/without leading slash, path variables replaced by regex-like fragments, snake/camel/kebab forms, and URL-encoded forms.
   - For Java/Spring-heavy projects, read `references/tracing-checklist.md` when useful.

3. Identify endpoint direction.
   - If the match is a controller/router, treat it as a possible customer-facing source endpoint.
   - If the match is a client/proxy/gateway call, trace callers upward until reaching controllers, message consumers, schedulers, or public gateway routes.
   - If multiple source endpoints call the target endpoint, report each flow separately.

4. Build the call chain.
   - Follow controller/route -> service/facade/orchestrator -> mapper/converter/assembler -> downstream client -> target endpoint.
   - Include interceptors, filters, validators, exception handlers, retry/circuit-breaker layers, async queues, feature flags, and config-driven route rewrites when they materially change behavior.
   - Record file paths and line numbers for each important claim.

5. Extract request mappings.
   - Compare source request DTOs, headers, query/path variables, auth/session/context fields, defaults, constants, config values, and computed fields against downstream request DTOs.
   - Classify each mapping as one of: direct, renamed, transformed, derived, defaulted, conditional, omitted, aggregated, split, unknown.
   - Capture conversion expressions, helper methods, enum/value translations, date/time/number formatting, null handling, validation, and fallback behavior.

6. Extract response mappings.
   - Compare downstream response DTOs to customer-facing response DTOs.
   - Capture direct copies, wrapping/unwrapping, filtering, sorting, enrichment from other calls, derived fields, status/result code translation, default values, and omitted downstream fields.

7. Trace error handling.
   - Find local `try/catch`, exception mappers/advice, client error decoders, retry policies, timeout handling, circuit breakers, validation failures, and downstream error-to-consumer error translations.
   - Include HTTP status, error code/body shape, logging/audit behavior, and whether errors are swallowed, converted, retried, or propagated.

8. Assign confidence.
   - `High`: confirmed by explicit code path and DTO/mapper evidence.
   - `Medium`: code strongly implies the mapping, but dynamic config/reflection/generation prevents full proof.
   - `Low`: naming or partial evidence only.
   - `Requires confirmation`: runtime routing, undocumented gateway behavior, missing generated sources, environment config, or ambiguous overloads make the conclusion unverifiable from local code.

9. Generate the report.
   - Prefer producing a structured JSON findings file first, then run `scripts/render_endpoint_report.py` to create HTML.
   - Embed PlantUML source in the report. If network/rendering is unavailable, include the diagram source in a readable code block; do not block the report on image rendering.
   - Save the report near the workspace root or in a user-requested output directory, with a name like `endpoint-flow-report-<safe-endpoint>.html`.

## Report Requirements

The HTML report must include:

- Executive summary: provided target endpoint, likely customer-facing source endpoint(s), confidence, and unresolved questions.
- Evidence inventory: key files, methods/classes, and route/config matches.
- End-to-end flow: concise steps and PlantUML sequence diagram source.
- Request mapping table: consumer field, source location, downstream field, mapping type, conversion/derivation logic, null/default behavior, evidence, confidence.
- Response mapping table: downstream field, consumer field, mapping type, conversion/derivation logic, omission/enrichment behavior, evidence, confidence.
- Error handling table: failure source, condition, local handling, downstream status/code, consumer status/code/body, retry/fallback behavior, evidence, confidence.
- Open questions: anything needing user confirmation, runtime config, generated sources, or environment access.

## Practical Search Patterns

Use fast, narrow searches first, then broaden:

```bash
rg -n "literal/path|operationName|DownstreamClient|RequestDto|ResponseDto" .
rg -n "@(Get|Post|Put|Delete|Patch)Mapping|@RequestMapping|RouterFunction|route\\(" .
rg -n "FeignClient|RestTemplate|WebClient|HttpClient|exchange\\(|retrieve\\(|postFor|send\\(" .
rg -n "Mapper|Converter|Assembler|Translator|Adapter|from\\(|to\\(|map\\(" .
rg -n "ControllerAdvice|ExceptionHandler|ErrorDecoder|Retry|CircuitBreaker|fallback|timeout" .
```

When `rg` finds too much, restrict by module, DTO name, package, or endpoint fragment. Prefer reading nearby files and referenced DTOs over trying to infer from search results alone.

## Bundled Resources

- `references/tracing-checklist.md`: framework and artifact checklist for common legacy endpoint tracing patterns.
- `scripts/render_endpoint_report.py`: renders a structured JSON trace into a standalone HTML report.
- `assets/report-style.css`: stylesheet embedded by the renderer.

