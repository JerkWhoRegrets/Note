---
name: endpoint-flow-tracer
description: Windows/Copilot skill to trace a provided SAPI, downstream, internal, or underlying API endpoint back to all customer-facing PAPI endpoints in a large legacy multi-module codebase. Trigger when the user provides a SAPI/downstream endpoint and asks to find PAPI callers, trace endpoint flow, analyze migration impact, map PAPI/SAPI fields, identify conversion or derivation logic, document validation/error handling, produce evidence-backed API behavior, or generate a migration-ready HTML report with PlantUML.
---

# Endpoint Flow Tracer

## Purpose

Trace from a provided SAPI endpoint back to every PAPI endpoint that calls it, then produce a migration-ready HTML report. Treat the SAPI request/response shape as stable and the current PAPI mapping, validation, defaulting, filtering, and error behavior as the compatibility contract to preserve.

This skill is for Copilot on Windows. Use PowerShell commands, Windows-friendly paths, and `py`/`python` script invocation.

## Workflow

1. Normalize the SAPI endpoint.
   - Capture method, path, host/base path, query parameters, headers, payload examples, module names, and downstream system names if provided.
   - Search broadly if method or module is missing; ask only when tracing cannot continue.

2. Find all code matches.
   - Prefer `rg`; fallback to PowerShell `Get-ChildItem ... | Select-String`.
   - Search literal path fragments, path constants, operation names, DTO names, generated clients, OpenAPI specs, route configs, and config keys.
   - Try variants with/without leading slash, path variables, snake/camel/kebab case, and URL-encoded forms.

3. Trace SAPI callers back to PAPI endpoints.
   - If the match is a client/proxy/gateway call, trace callers upward through services/facades/orchestrators until reaching controllers, public gateway routes, message consumers, or schedulers.
   - Continue after the first caller. Record every PAPI endpoint that can call the same SAPI.
   - If multiple PAPI endpoints call the SAPI, report each flow and highlight the situation in `5. References and Evidence` as a migration risk/confirmation item.

4. Build each end-to-end flow.
   - Follow PAPI route -> validator/filter/interceptor -> service/facade -> mapper/converter/assembler -> SAPI client -> SAPI endpoint -> response mapper -> PAPI response.
   - Include retries, timeouts, circuit breakers, fallbacks, feature flags, async queues, and config-driven route rewrites when they affect behavior.
   - Use repository-relative evidence paths, for example `customer-papi\src\main\java\...\CustomerController.java:42`.

5. Extract data mappings.
   - Request table columns must be exactly: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - Response table columns must be exactly: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - In `Comments`, include direct copies, renames, transformations, derived/default values, omitted fields, enum/date/number conversions, null behavior, conditions, and evidence IDs.

6. Capture examples.
   - Include valid JSON for PAPI request, SAPI request, SAPI response, and PAPI response.
   - Keep headers and payloads visible. Put uncertainty in nearby notes, not invalid JSON comments.

7. Trace error handling.
   - Capture validation, null/blank/malformed behavior, downstream status/code/body translation, retries/fallbacks/timeouts, exception mapping, logging/audit behavior, and final PAPI error response shape.
   - Be explicit for key fields: if null/blank/malformed/out-of-range/unknown enum occurs, state whether PAPI errors, defaults, continues, omits, calls SAPI, retries, or maps an error.

8. Assign confidence.
   - `High`: continuous code path plus DTO/mapper/error evidence.
   - `Medium`: strong code evidence but generated/dynamic/config behavior hides part of the proof.
   - `Low`: partial evidence or naming-based inference.
   - `Requires confirmation`: runtime-only routing, missing generated sources, environment config, reflection, or ambiguous overloads.

9. Generate the HTML report.
   - Build HTML directly when faster for one-off or smaller traces.
   - Use `scripts\render_endpoint_report.py` with JSON only for large reports, repeatable regeneration, many PAPI flows, programmatic edits, or when the user wants structured findings preserved.
   - If generating directly, still follow the exact report order and table columns below. Inline `assets\report-style.css` or equivalent simple styling.
   - Include PlantUML source as readable text; do not block on rendering an image.

## Report Order

1. End-to-End Flow
   - Include PAPI endpoint(s), SAPI endpoint, modules/classes/methods, validators, mappers, service orchestration, downstream call, response mapping, and return path.
   - Include PlantUML sequence source here.

2. Data Mapping
   - `Request table`: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.
   - `Response table`: `PAPI attribute type`, `PAPI attribute`, `SAPI attribute type`, `SAPI attribute`, `Comments`, `Confidence level`.

3. Request and Response Examples
   - PAPI request, SAPI request, SAPI response, PAPI response as valid JSON.

4. Error Handling Logic
   - Detailed validation, null/default behavior, downstream errors, retries/fallbacks/timeouts, exception mapping, and final PAPI error shape.

5. References and Evidence
   - If multiple PAPI endpoints call the same SAPI, put a highlighted note first and list every PAPI caller with evidence.
   - List evidence for route discovery, mapping/derivation comments, error handling, confidence decisions, and open questions.

## Windows Commands

Search with `rg`:

```powershell
rg -n "literal/path|operationName|DownstreamClient|RequestDto|ResponseDto" .
rg -n "@(Get|Post|Put|Delete|Patch)Mapping|@RequestMapping|RouterFunction|route\(" .
rg -n "FeignClient|RestTemplate|WebClient|HttpClient|exchange\(|retrieve\(|postFor|send\(" .
rg -n "Mapper|Converter|Assembler|Translator|Adapter|from\(|to\(|map\(" .
rg -n "ControllerAdvice|ExceptionHandler|ErrorDecoder|Retry|CircuitBreaker|fallback|timeout" .
```

Fallback when `rg` is unavailable:

```powershell
Get-ChildItem -Recurse -File | Select-String -Pattern "literal/path","DownstreamClient","RequestDto","ResponseDto" | Select-Object Path, LineNumber, Line
Get-ChildItem -Recurse -Include *.java,*.kt,*.yml,*.yaml,*.properties,*.json -File | Select-String -Pattern "@RequestMapping","FeignClient","RestTemplate","WebClient","ControllerAdvice","ExceptionHandler"
```

Renderer:

```powershell
py .\scripts\render_endpoint_report.py .\sample-trace.json .\reports\endpoint-flow-report.html
```

Windows rules:

- Quote paths with spaces.
- Use `Join-Path`, `pathlib.Path`, or relative paths such as `.\reports\endpoint-flow-report.html`.
- Use PowerShell-native commands and `py`/`python` to run helper scripts.

## Bundled Resources

- `references\tracing-checklist.md`: compact tracing checklist.
- `scripts\render_endpoint_report.py`: optional JSON-to-HTML renderer.
- `assets\report-style.css`: HTML report styling.
