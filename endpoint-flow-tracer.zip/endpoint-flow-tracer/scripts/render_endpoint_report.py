r"""Render endpoint-flow trace JSON to a standalone HTML report.

Windows PowerShell:
  py .\scripts\render_endpoint_report.py .\sample-trace.json .\reports\endpoint-flow-report.html
"""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
STYLE_PATH = ROOT / "assets" / "report-style.css"


def esc(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, indent=2)
    return html.escape(str(value))


def badge(confidence: str | None) -> str:
    label = confidence or "Unknown"
    cls = label.replace(" ", "-")
    return f'<span class="badge {esc(cls)}">{esc(label)}</span>'


def first_value(row: dict[str, Any], keys: list[str]) -> Any:
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return value
    return ""


def table(rows: list[dict[str, Any]], columns: list[tuple[str, str]]) -> str:
    if not rows:
        return '<p class="muted">No entries found.</p>'
    head = "".join(f"<th>{esc(label)}</th>" for _, label in columns)
    body_rows = []
    for row in rows:
        cells = []
        for key, _ in columns:
            keys = key.split("|")
            value = first_value(row, keys)
            if "confidence" in keys or "confidence_level" in keys:
                cells.append(f"<td>{badge(str(value) if value else None)}</td>")
            else:
                cells.append(f"<td>{esc(value)}</td>")
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body_rows)}</tbody></table>"


def list_items(items: list[Any]) -> str:
    if not items:
        return '<p class="muted">None recorded.</p>'
    return "<ul>" + "".join(f"<li>{esc(item)}</li>" for item in items) + "</ul>"


def flow_steps(steps: list[dict[str, Any]]) -> str:
    if not steps:
        return '<p class="muted">No flow steps recorded.</p>'
    blocks = []
    for idx, step in enumerate(steps, 1):
        title = step.get("title") or step.get("name") or f"Step {idx}"
        detail = step.get("detail") or step.get("description") or ""
        evidence = step.get("evidence") or ""
        blocks.append(
            '<div class="flow-step">'
            f'<span class="step-num">{idx}</span>'
            f'<div><strong>{esc(title)}</strong><div>{esc(detail)}</div>'
            f'<div class="muted">{esc(evidence)}</div></div></div>'
        )
    return "".join(blocks)


def json_block(value: Any) -> str:
    if value in (None, ""):
        value = {}
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError:
            return f"<pre>{esc(value)}</pre>"
    return f"<pre>{esc(json.dumps(value, ensure_ascii=False, indent=2))}</pre>"


def examples(data: dict[str, Any]) -> str:
    examples_data = data.get("examples") or {}
    papi_request = examples_data.get("papi_request", data.get("papi_request_example"))
    sapi_request = examples_data.get("sapi_request", data.get("sapi_request_example"))
    sapi_response = examples_data.get("sapi_response", data.get("sapi_response_example"))
    papi_response = examples_data.get("papi_response", data.get("papi_response_example"))
    notes = examples_data.get("notes") or data.get("example_notes") or []
    return (
        '<div class="example-grid">'
        f'<section class="panel"><h3>PAPI Request</h3>{json_block(papi_request)}</section>'
        f'<section class="panel"><h3>SAPI Request</h3>{json_block(sapi_request)}</section>'
        f'<section class="panel"><h3>SAPI Response</h3>{json_block(sapi_response)}</section>'
        f'<section class="panel"><h3>PAPI Response</h3>{json_block(papi_response)}</section>'
        '</div>'
        f'<div class="panel"><h3>Example Notes</h3>{list_items(notes)}</div>'
    )


def multiple_papi_warning(data: dict[str, Any], source: list[Any]) -> str:
    callers = data.get("multiple_papi_callers") or data.get("papi_callers") or []
    if not callers and len(source) > 1:
        callers = [{"endpoint": item} for item in source]
    if len(callers) <= 1:
        return ""

    rows = []
    for caller in callers:
        if isinstance(caller, dict):
            endpoint = caller.get("endpoint") or caller.get("papi_endpoint") or caller.get("route") or ""
            artifact = caller.get("artifact") or caller.get("evidence") or ""
            notes = caller.get("notes") or caller.get("role") or "Calls the same SAPI endpoint."
        else:
            endpoint = str(caller)
            artifact = ""
            notes = "Calls the same SAPI endpoint."
        rows.append(
            "<tr>"
            f"<td>{esc(endpoint)}</td>"
            f"<td>{esc(artifact)}</td>"
            f"<td>{esc(notes)}</td>"
            "</tr>"
        )

    return (
        '<section class="warning-panel">'
        "<h3>Multiple PAPI Callers Detected</h3>"
        "<p>This SAPI endpoint is called by multiple PAPI endpoints. Treat each caller as a separate migration flow and confirm whether the new API must preserve all caller-specific mapping and error behavior.</p>"
        "<table><thead><tr><th>PAPI Endpoint</th><th>Evidence</th><th>Notes</th></tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
        "</section>"
    )


def render(data: dict[str, Any]) -> str:
    css = STYLE_PATH.read_text(encoding="utf-8") if STYLE_PATH.exists() else ""
    title = data.get("title") or "Endpoint Flow Report"
    target = data.get("target_endpoint") or data.get("endpoint") or "Unknown endpoint"
    generated = data.get("generated_at") or ""
    source = data.get("source_endpoints") or []
    if isinstance(source, str):
        source = [source]

    request_columns = [
        ("papi_attribute_type|consumer_attribute_type|consumer_type", "PAPI Attribute Type"),
        ("papi_attribute|consumer_field|consumer_attribute", "PAPI Attribute"),
        ("sapi_attribute_type|downstream_attribute_type|downstream_type", "SAPI Attribute Type"),
        ("sapi_attribute|downstream_field|downstream_attribute", "SAPI Attribute"),
        ("comments|logic|comment", "Comments"),
        ("confidence_level|confidence", "Confidence Level"),
    ]
    response_columns = [
        ("papi_attribute_type|consumer_attribute_type|consumer_type", "PAPI Attribute Type"),
        ("papi_attribute|consumer_field|consumer_attribute", "PAPI Attribute"),
        ("sapi_attribute_type|downstream_attribute_type|downstream_type", "SAPI Attribute Type"),
        ("sapi_attribute|downstream_field|downstream_attribute", "SAPI Attribute"),
        ("comments|logic|behavior|comment", "Comments"),
        ("confidence_level|confidence", "Confidence Level"),
    ]
    error_columns = [
        ("scenario|failure_source", "Scenario"),
        ("condition", "Condition"),
        ("papi_behavior|handling", "Existing PAPI Behavior"),
        ("sapi_behavior|downstream_error", "SAPI / Downstream Behavior"),
        ("migration_requirement|consumer_error", "Migration Requirement"),
        ("retry_fallback", "Retry / Fallback"),
        ("confidence_level|confidence", "Confidence Level"),
    ]
    evidence_columns = [
        ("reference_id|id", "Ref"),
        ("artifact", "Artifact"),
        ("role", "Role"),
        ("evidence", "Evidence"),
        ("proves|derivation", "What It Proves"),
        ("confidence_level|confidence", "Confidence Level"),
    ]

    plantuml = data.get("plantuml") or "@startuml\nparticipant Consumer\nparticipant Service\nparticipant Downstream\nConsumer -> Service: request\nService -> Downstream: mapped request\nDownstream --> Service: response\nService --> Consumer: mapped response\n@enduml"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <style>{css}</style>
</head>
<body>
  <header>
    <h1>{esc(title)}</h1>
    <div class="meta">Target endpoint: <code>{esc(target)}</code>{' | Generated: ' + esc(generated) if generated else ''}</div>
  </header>
  <main>
    <section class="grid">
      <div class="panel"><h3>PAPI Endpoint(s)</h3>{list_items(source)}</div>
      <div class="panel"><h3>SAPI Endpoint</h3><p><code>{esc(target)}</code></p></div>
      <div class="panel"><h3>Overall Confidence</h3>{badge(data.get("overall_confidence"))}<p>{esc(data.get("confidence_notes", ""))}</p></div>
    </section>

    <h2>1. End-to-End Flow</h2>
    <div class="panel">{esc(data.get("summary", ""))}</div>
    <div class="panel">{flow_steps(data.get("flow_steps", []))}</div>
    <h3>PlantUML Sequence Diagram</h3>
    <pre>{esc(plantuml)}</pre>

    <h2>2. Data Mapping</h2>
    <h3>Request Table</h3>
    {table(data.get("request_mappings", []), request_columns)}
    <h3>Response Table</h3>
    {table(data.get("response_mappings", []), response_columns)}

    <h2>3. Request and Response Examples</h2>
    {examples(data)}

    <h2>4. Error Handling Logic</h2>
    {table(data.get("error_handling", []), error_columns)}

    <h2>5. References and Evidence</h2>
    {multiple_papi_warning(data, source)}
    {table(data.get("evidence_inventory", data.get("references", [])), evidence_columns)}
    <h3>Open Questions / Confirmation Needed</h3>
    <div class="panel">{list_items(data.get("open_questions", []))}</div>
  </main>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Render endpoint-flow trace JSON to a standalone HTML report.",
        epilog=(
            "Windows PowerShell example: "
            "py .\\scripts\\render_endpoint_report.py .\\sample-trace.json .\\endpoint-flow-report.html"
        ),
    )
    parser.add_argument("input_json", help="Path to endpoint trace JSON findings")
    parser.add_argument("output_html", help="Path to write HTML report")
    args = parser.parse_args()

    input_path = Path(args.input_json)
    output_path = Path(args.output_html)
    data = json.loads(input_path.read_text(encoding="utf-8"))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(render(data), encoding="utf-8")
    print(f"Wrote {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
