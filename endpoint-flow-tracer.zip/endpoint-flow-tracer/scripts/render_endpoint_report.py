#!/usr/bin/env python3
"""Render endpoint-flow trace JSON to a standalone HTML report."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
STYLE_PATH = ROOT / "assets" / "report-style.css"


def esc(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False, indent=2)
    return html.escape(str(value))


def badge(confidence: str | None) -> str:
    label = confidence or "Unknown"
    cls = label.replace(" ", "-")
    return f'<span class="badge {esc(cls)}">{esc(label)}</span>'


def table(rows: list[dict[str, Any]], columns: list[tuple[str, str]]) -> str:
    if not rows:
        return '<p class="muted">No entries found.</p>'
    head = "".join(f"<th>{esc(label)}</th>" for _, label in columns)
    body_rows = []
    for row in rows:
        cells = []
        for key, _ in columns:
            value = row.get(key, "")
            if key == "confidence":
                cells.append(f"<td>{badge(str(value) if value else None)}</td>")
            else:
                cells.append(f"<td>{esc(value)}</td>")
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body_rows)}</tbody></table>"


def list_items(items: list[Any]) -> str:
    if not items:
        return '<p class="muted">None recorded.</p>'
    return "<ul>" + "".join(f"<li>{esc(item)}</li>" for item in items) + "</ul>"


def flow_steps(steps: list[dict[str, Any]]) -> str:
    if not steps:
        return '<p class="muted">No flow steps recorded.</p>'
    blocks = []
    for idx, step in enumerate(steps, 1):
        title = step.get("title") or step.get("name") or f"Step {idx}"
        detail = step.get("detail") or step.get("description") or ""
        evidence = step.get("evidence") or ""
        blocks.append(
            '<div class="flow-step">'
            f'<span class="step-num">{idx}</span>'
            f'<div><strong>{esc(title)}</strong><div>{esc(detail)}</div>'
            f'<div class="muted">{esc(evidence)}</div></div></div>'
        )
    return "".join(blocks)


def render(data: dict[str, Any]) -> str:
    css = STYLE_PATH.read_text(encoding="utf-8") if STYLE_PATH.exists() else ""
    title = data.get("title") or "Endpoint Flow Report"
    target = data.get("target_endpoint") or data.get("endpoint") or "Unknown endpoint"
    generated = data.get("generated_at") or ""
    source = data.get("source_endpoints") or []
    if isinstance(source, str):
        source = [source]

    request_columns = [
        ("consumer_field", "Consumer Field"),
        ("source", "Source"),
        ("downstream_field", "Downstream Field"),
        ("mapping_type", "Type"),
        ("logic", "Conversion / Derivation Logic"),
        ("null_default_behavior", "Null / Default Behavior"),
        ("evidence", "Evidence"),
        ("confidence", "Confidence"),
    ]
    response_columns = [
        ("downstream_field", "Downstream Field"),
        ("consumer_field", "Consumer Field"),
        ("mapping_type", "Type"),
        ("logic", "Conversion / Derivation Logic"),
        ("behavior", "Omission / Enrichment Behavior"),
        ("evidence", "Evidence"),
        ("confidence", "Confidence"),
    ]
    error_columns = [
        ("failure_source", "Failure Source"),
        ("condition", "Condition"),
        ("handling", "Handling"),
        ("downstream_error", "Downstream Error"),
        ("consumer_error", "Consumer Error"),
        ("retry_fallback", "Retry / Fallback"),
        ("evidence", "Evidence"),
        ("confidence", "Confidence"),
    ]
    evidence_columns = [
        ("artifact", "Artifact"),
        ("role", "Role"),
        ("evidence", "Evidence"),
        ("confidence", "Confidence"),
    ]

    plantuml = data.get("plantuml") or "@startuml\nparticipant Consumer\nparticipant Service\nparticipant Downstream\nConsumer -> Service: request\nService -> Downstream: mapped request\nDownstream --> Service: response\nService --> Consumer: mapped response\n@enduml"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <style>{css}</style>
</head>
<body>
  <header>
    <h1>{esc(title)}</h1>
    <div class="meta">Target endpoint: <code>{esc(target)}</code>{' | Generated: ' + esc(generated) if generated else ''}</div>
  </header>
  <main>
    <section class="grid">
      <div class="panel"><h3>Likely Source Endpoint(s)</h3>{list_items(source)}</div>
      <div class="panel"><h3>Overall Confidence</h3>{badge(data.get("overall_confidence"))}<p>{esc(data.get("confidence_notes", ""))}</p></div>
      <div class="panel"><h3>Open Questions</h3>{list_items(data.get("open_questions", []))}</div>
    </section>

    <h2>Executive Summary</h2>
    <div class="panel">{esc(data.get("summary", ""))}</div>

    <h2>Evidence Inventory</h2>
    {table(data.get("evidence_inventory", []), evidence_columns)}

    <h2>End-to-End Flow</h2>
    <div class="panel">{flow_steps(data.get("flow_steps", []))}</div>

    <h2>PlantUML Sequence Diagram</h2>
    <pre>{esc(plantuml)}</pre>

    <h2>Request Mapping</h2>
    {table(data.get("request_mappings", []), request_columns)}

    <h2>Response Mapping</h2>
    {table(data.get("response_mappings", []), response_columns)}

    <h2>Error Handling</h2>
    {table(data.get("error_handling", []), error_columns)}
  </main>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_json", help="Path to endpoint trace JSON findings")
    parser.add_argument("output_html", help="Path to write HTML report")
    args = parser.parse_args()

    input_path = Path(args.input_json)
    output_path = Path(args.output_html)
    data = json.loads(input_path.read_text(encoding="utf-8"))
    output_path.write_text(render(data), encoding="utf-8")
    print(f"Wrote {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
