# Endpoint Tracing Checklist

Use this reference when tracing endpoint flow in large legacy services, especially Java/Spring multi-module repositories. Adapt the artifact names to the stack in front of you. For migration work, treat the current PAPI behavior as the compatibility contract and the SAPI request/response shape as the stable downstream contract.

## Route Discovery

- Controllers: `@RestController`, `@Controller`, `@RequestMapping`, `@GetMapping`, `@PostMapping`, `@PutMapping`, `@PatchMapping`, `@DeleteMapping`.
- Functional routes: `RouterFunction`, `route()`, handler classes, route locator configuration.
- Gateway/proxy config: YAML/properties route predicates, rewrite filters, service IDs, Zuul/Spring Cloud Gateway routes, API gateway descriptors.
- API specs: OpenAPI/Swagger YAML or JSON, RAML, WADL, generated API interfaces, `operationId`.
- Non-HTTP sources: Kafka/JMS consumers, batch jobs, schedulers, CLI handlers, GraphQL resolvers, gRPC services.
- Multiple PAPI callers: when starting from a SAPI endpoint, continue caller search after finding the first PAPI. Record every PAPI endpoint that can reach the same SAPI and include evidence for each caller in the final References and Evidence section.

## Downstream Call Discovery

- Declarative clients: Feign interfaces, Retrofit clients, generated OpenAPI clients.
- Programmatic clients: `RestTemplate`, `WebClient`, Apache/OkHttp clients, custom HTTP wrappers.
- Config-driven paths: properties such as `base-url`, `endpoint`, `uri`, `path`, service discovery names, route aliases.
- Resilience wrappers: retry templates, circuit breakers, fallbacks, bulkheads, timeout config.

## Mapping Artifacts

- DTOs and records: request/response classes, validation annotations, JSON property annotations, builder defaults.
- Mappers: MapStruct interfaces, converter classes, assemblers, translators, adapters, static factory methods.
- Serialization: `@JsonProperty`, `@JsonAlias`, `@JsonIgnore`, custom serializers/deserializers, naming strategy config.
- Enrichment: repository lookups, cache reads, secondary API calls, context/session/user profile data.
- Defaults and derivations: constants, feature flags, null coalescing, enum mapping, date/time formatting, currency/units conversion, trimming/sanitization, ID composition/splitting.
- Migration-critical behavior: PAPI-only defaults, field omissions before calling SAPI, headers injected from context, status or error code translations, and transformations that the new API must preserve.

## Error Handling Artifacts

- Local handling: `try/catch`, checked exception conversions, validation exceptions.
- Global handling: `@ControllerAdvice`, `@ExceptionHandler`, filters, middleware, error controllers.
- Client handling: Feign `ErrorDecoder`, WebClient `onStatus`, RestTemplate `ResponseErrorHandler`, custom response wrappers.
- Operational behavior: retries, fallback methods, circuit breaker open behavior, timeout mapping, partial success handling.
- Error payload shape: consumer status, error code, message, details, trace IDs, downstream status/code/body preservation.

## Confidence Guidance

- High confidence requires a continuous, readable code path with concrete DTO or mapper evidence.
- Medium confidence is appropriate when generated code, framework conventions, or dynamic dispatch obscure a small part of an otherwise clear path.
- Low confidence is appropriate for name-based matches, partial call chains, or incomplete DTO visibility.
- Mark `Requires confirmation` for runtime-only gateway routing, missing generated sources, environment-specific config, reflection-heavy mapping, or ambiguous overloaded methods.

## Evidence Tips

- Capture file path and line number for route definitions, downstream client method, mapper method, DTO fields, and error translation.
- Prefer exact method names and field names in tables.
- If a mapping is conditional, include the condition and both branches.
- If a field is omitted, say whether it is intentionally ignored, impossible to determine, or never returned by the downstream API.
- Use short reference IDs such as `REQ-1`, `RES-3`, and `ERR-2` in mapping/error comments, then explain each ID in the final References and Evidence section.
