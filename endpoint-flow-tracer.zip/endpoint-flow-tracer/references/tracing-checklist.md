# Endpoint Tracing Checklist

Use this Windows/Copilot checklist when tracing from a SAPI endpoint back to all PAPI callers. Treat current PAPI behavior as the migration compatibility contract and SAPI request/response shape as stable.

## Discover PAPI Callers

- Search SAPI path fragments, constants, operation names, generated client methods, Feign interfaces, `RestTemplate`, `WebClient`, HTTP wrappers, OpenAPI specs, YAML/properties route config, and service discovery aliases.
- Continue after the first caller. Record every PAPI route/controller/message consumer/scheduler that can reach the same SAPI.
- If multiple PAPI callers exist, highlight them in the final References and Evidence section with endpoint, method/class, and evidence.

## Trace Flow Artifacts

- Routes: `@RestController`, `@Controller`, `@RequestMapping`, `@GetMapping`, `@PostMapping`, `@PutMapping`, `@PatchMapping`, `@DeleteMapping`, `RouterFunction`, gateway routes.
- Mapping: DTOs, records, validation annotations, `@JsonProperty`, MapStruct, converters, assemblers, translators, adapters, static factories.
- Derivation: constants, defaults, feature flags, enum mapping, date/time formatting, currency/units conversion, trimming/sanitization, ID split/composition, context/session/header injection.
- Errors: `try/catch`, `@ControllerAdvice`, `@ExceptionHandler`, Feign `ErrorDecoder`, WebClient `onStatus`, `ResponseErrorHandler`, retries, circuit breakers, fallbacks, timeouts.

## Evidence Rules

- Use repository-relative Windows-friendly paths, for example `customer-papi\src\main\java\...\CustomerController.java:42`.
- Avoid local absolute paths like `C:\Users\...` unless the user asks.
- Use short reference IDs such as `REQ-1`, `RES-3`, and `ERR-2` in table comments, then explain each ID in References and Evidence.
- Mark confidence as `High`, `Medium`, `Low`, or `Requires confirmation`.

## PowerShell Search

```powershell
rg -n "literal/path|operationName|DownstreamClient|RequestDto|ResponseDto" .
rg -n "FeignClient|RestTemplate|WebClient|HttpClient|exchange\(|retrieve\(|postFor|send\(" .
rg -n "Mapper|Converter|Assembler|Translator|Adapter|from\(|to\(|map\(" .
rg -n "ControllerAdvice|ExceptionHandler|ErrorDecoder|Retry|CircuitBreaker|fallback|timeout" .
```

Fallback:

```powershell
Get-ChildItem -Recurse -File | Select-String -Pattern "literal/path","DownstreamClient","RequestDto","ResponseDto" | Select-Object Path, LineNumber, Line
```
